import java.lang.*;
import Frames.*;



public class Start
{
	public static void main(String[] args)
	{
		
		users us=new users();

		frame f1 = new frame(us);
		f1.setVisible(true);
		
		
		

		
		
		
	}
}
